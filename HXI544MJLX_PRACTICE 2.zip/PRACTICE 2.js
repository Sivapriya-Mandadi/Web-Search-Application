function calculate() {
    let yearEl = parseInt(document.getElementById("year").value);
    let monthEl = parseInt(document.getElementById("month").value);
    let dateEl = parseInt(document.getElementById("date").value);
    let amountEl = parseFloat(document.getElementById("amount").value);
    let interestEl = parseFloat(document.getElementById("interest").value);
    let resultEl = document.getElementById("result");
    let totalAmountEl = document.getElementById("totalAmount");

    // Check if any input is NaN
    if (isNaN(yearEl) || isNaN(monthEl) || isNaN(dateEl) || isNaN(amountEl) || isNaN(interestEl)) {
        resultEl.textContent = "Please fill all the fields with valid numeric values.";
        totalAmountEl.textContent = "";
        return;
    }

    let totalDays = (yearEl * 365) + (monthEl * 30) + dateEl;
    let interestAmount = totalDays * interestEl; // Assuming interest is in percentage
    let total = amountEl + interestAmount;

    resultEl.textContent = "Interest Amount: " + interestAmount.toFixed(2);
    totalAmountEl.textContent = "Total: " + total.toFixed(2);
}